import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";

export const useFadeInUp = (startFrame: number, duration = 20) => {
  const frame = useCurrentFrame();
  const progress = interpolate(
    frame - startFrame,
    [0, duration],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );
  return {
    opacity: progress,
    transform: `translateY(${(1 - progress) * 40}px)`,
  };
};

export const usePop = (startFrame: number) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const scale = spring({
    frame: frame - startFrame,
    fps,
    config: { damping: 12, stiffness: 120, mass: 0.8 },
  });
  return { transform: `scale(${scale})`, opacity: Math.min(scale, 1) };
};

export const useProgress = (start: number, end: number) => {
  const frame = useCurrentFrame();
  return interpolate(frame, [start, end], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

// Kenburns-style slow zoom for screenshots
export const useKenBurns = (startFrame: number, duration: number, zoom = 1.15) => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame - startFrame, [0, duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const scale = 1 + progress * (zoom - 1);
  return { transform: `scale(${scale})` };
};
