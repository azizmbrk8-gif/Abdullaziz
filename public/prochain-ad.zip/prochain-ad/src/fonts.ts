import { loadFont as loadTajawal } from "@remotion/google-fonts/Tajawal";
import { loadFont as loadCairo } from "@remotion/google-fonts/Cairo";

// Load Arabic fonts
loadTajawal("normal", { weights: ["400", "500", "700", "800", "900"] });
loadCairo("normal", { weights: ["400", "600", "700", "800", "900"] });

export const fontFamily = {
  display: '"Tajawal", system-ui, sans-serif',
  body: '"Cairo", system-ui, sans-serif',
};
