import { Composition } from "remotion";
import { ProChainAd } from "./ProChainAd";

// Total: 40 seconds @ 30fps = 1200 frames, 9:16 vertical (1080x1920)
export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="ProChainAd"
        component={ProChainAd}
        durationInFrames={1200}
        fps={30}
        width={1080}
        height={1920}
      />
    </>
  );
};
