import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import "./fonts"; // triggers Arabic font loading
import { Scene1Hook } from "./scenes/Scene1Hook";
import { Scene2Pain } from "./scenes/Scene2Pain";
import { Scene3Intro } from "./scenes/Scene3Intro";
import { Scene4Demo } from "./scenes/Scene4Demo";
import { Scene5Benefits } from "./scenes/Scene5Benefits";
import { Scene6Service } from "./scenes/Scene6Service";
import { Scene7WinWin } from "./scenes/Scene7WinWin";
import { Scene8CTA } from "./scenes/Scene8CTA";

// Timeline @ 30fps:
// Scene 1: 0-3s    (0-90)    Hook
// Scene 2: 3-8s    (90-240)  Pain points
// Scene 3: 8-12s   (240-360) ProChain intro
// Scene 4: 12-22s  (360-660) Real app demo
// Scene 5: 22-29s  (660-870) Benefits
// Scene 6: 29-35s  (870-1050) Service flow
// Scene 7: 35-38s  (1050-1140) Win-win
// Scene 8: 38-40s  (1140-1200) CTA

export const ProChainAd: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Sequence from={0} durationInFrames={90}>
      <Scene1Hook />
    </Sequence>
    <Sequence from={90} durationInFrames={150}>
      <Scene2Pain />
    </Sequence>
    <Sequence from={240} durationInFrames={120}>
      <Scene3Intro />
    </Sequence>
    <Sequence from={360} durationInFrames={300}>
      <Scene4Demo />
    </Sequence>
    <Sequence from={660} durationInFrames={210}>
      <Scene5Benefits />
    </Sequence>
    <Sequence from={870} durationInFrames={180}>
      <Scene6Service />
    </Sequence>
    <Sequence from={1050} durationInFrames={90}>
      <Scene7WinWin />
    </Sequence>
    <Sequence from={1140} durationInFrames={60}>
      <Scene8CTA />
    </Sequence>
  </AbsoluteFill>
);
