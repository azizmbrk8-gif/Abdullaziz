// ProChain Brand System — matched from actual app screens
export const theme = {
  colors: {
    // Primary: warm orange from app header
    primary: "#F28B2E",
    primaryDark: "#D66D12",
    primaryLight: "#FFA851",
    
    // Gold accent from logo
    gold: "#F4B942",
    goldDark: "#D99820",
    
    // Dark charcoal navy from logo
    ink: "#2C3540",
    inkMid: "#4A5560",
    inkMuted: "#8B95A3",
    inkLight: "#C4CBD4",
    
    // Cream/warm backgrounds
    cream: "#FAF6F0",
    creamWarm: "#FFF3E6",
    surface: "#FFFFFF",
    
    // States
    danger: "#E74C3C",
    success: "#4CAF50",
    info: "#7B68EE",
    
    white: "#FFFFFF",
  },
  
  gradients: {
    // Main brand gradient from app header
    primary: "linear-gradient(135deg, #F28B2E 0%, #FFA851 100%)",
    primaryDeep: "linear-gradient(180deg, #F28B2E 0%, #D66D12 100%)",
    // Cream background gradient
    cream: "linear-gradient(180deg, #FAF6F0 0%, #FFF3E6 100%)",
    // Warm glow
    warmGlow: "radial-gradient(circle, rgba(242, 139, 46, 0.4) 0%, rgba(242, 139, 46, 0) 70%)",
    // Gold accent gradient
    gold: "linear-gradient(135deg, #F4B942 0%, #F28B2E 100%)",
  },
  
  fonts: {
    // Arabic-first fonts via Google Fonts (loaded in Root)
    display: '"Tajawal", "IBM Plex Sans Arabic", system-ui, sans-serif',
    body: '"Cairo", "Tajawal", system-ui, sans-serif',
  },
  
  shadows: {
    sm: "0 4px 12px rgba(242, 139, 46, 0.12)",
    md: "0 12px 32px rgba(242, 139, 46, 0.2)",
    lg: "0 24px 60px rgba(242, 139, 46, 0.3)",
    glow: "0 0 80px rgba(244, 185, 66, 0.5)",
    subtle: "0 8px 24px rgba(44, 53, 64, 0.08)",
  },
};
