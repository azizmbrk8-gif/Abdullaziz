import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { fontFamily } from "../fonts";
import { ProChainLogo } from "../components/Logo";

export const Scene8CTA: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  
  const logoScale = spring({
    frame: frame - 5,
    fps,
    config: { damping: 10, stiffness: 100 },
  });
  
  const headlineProgress = interpolate(frame, [25, 45], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  
  const buttonProgress = interpolate(frame, [40, 60], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  
  const linkProgress = interpolate(frame, [60, 75], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  
  const pulse = 1 + Math.sin(frame * 0.2) * 0.03;
  
  const shinePos = interpolate(frame, [45, 95], [-100, 200], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ background: theme.gradients.primary }} />
      
      <AbsoluteFill
        style={{
          background: "radial-gradient(circle at center, rgba(255,255,255,0.35) 0%, transparent 50%)",
        }}
      />
      
      <AbsoluteFill
        style={{
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: 60,
        }}
      >
        <div
          style={{
            transform: `scale(${logoScale})`,
            opacity: logoScale,
          }}
        >
          <ProChainLogo size={260} variant="light" />
        </div>
        
        <div
          style={{
            opacity: headlineProgress,
            transform: `translateY(${(1 - headlineProgress) * 30}px)`,
            fontFamily: fontFamily.display,
            fontSize: 88,
            fontWeight: 900,
            color: theme.colors.white,
            textAlign: "center",
            lineHeight: 1.05,
            direction: "rtl",
            textShadow: "0 4px 20px rgba(0,0,0,0.2)",
          }}
        >
          انضم اليوم
        </div>
        
        <div
          style={{
            opacity: buttonProgress,
            transform: `scale(${buttonProgress * pulse})`,
            background: theme.colors.white,
            padding: "32px 80px",
            borderRadius: 999,
            boxShadow: theme.shadows.glow,
            position: "relative",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              fontFamily: fontFamily.display,
              fontSize: 54,
              fontWeight: 900,
              color: theme.colors.primary,
              direction: "rtl",
            }}
          >
            ابدأ الآن ←
          </div>
          <div
            style={{
              position: "absolute",
              top: 0,
              left: `${shinePos}%`,
              width: "40%",
              height: "100%",
              background: "linear-gradient(90deg, transparent, rgba(242,139,46,0.25), transparent)",
              transform: "skewX(-20deg)",
            }}
          />
        </div>
        
        <div
          style={{
            opacity: linkProgress,
            transform: `translateY(${(1 - linkProgress) * 20}px)`,
            fontFamily: fontFamily.body,
            fontSize: 36,
            fontWeight: 700,
            color: theme.colors.white,
            background: "rgba(255,255,255,0.2)",
            padding: "18px 44px",
            borderRadius: 999,
            border: "2px solid rgba(255,255,255,0.4)",
            direction: "rtl",
          }}
        >
          🔗 الرابط في البايو
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
