import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig, Sequence } from "remotion";
import { theme } from "../theme";
import { fontFamily } from "../fonts";
import { ProChainLogo } from "../components/Logo";
import { GradientBG } from "../components/Background";
import { Caption } from "../components/Caption";

export const Scene3Intro: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  
  const wipeProgress = interpolate(frame, [0, 20], [0, 1], {
    extrapolateRight: "clamp",
  });
  
  const logoScale = spring({
    frame: frame - 15,
    fps,
    config: { damping: 10, stiffness: 100 },
  });
  
  const taglineAnim = interpolate(frame, [40, 60], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ background: theme.colors.ink }} />
      
      <AbsoluteFill
        style={{
          clipPath: `inset(${(1 - wipeProgress) * 100}% 0 0 0)`,
        }}
      >
        <GradientBG variant="cream" />
        
        <AbsoluteFill
          style={{
            alignItems: "center",
            justifyContent: "center",
            flexDirection: "column",
            gap: 50,
          }}
        >
          <div
            style={{
              transform: `scale(${logoScale})`,
              opacity: logoScale,
            }}
          >
            <ProChainLogo size={280} variant="dark" />
          </div>
          
          <div
            style={{
              opacity: taglineAnim,
              transform: `translateY(${(1 - taglineAnim) * 20}px)`,
              fontFamily: fontFamily.body,
              fontSize: 44,
              fontWeight: 600,
              color: theme.colors.inkMid,
              textAlign: "center",
              maxWidth: "80%",
              direction: "rtl",
              lineHeight: 1.3,
            }}
          >
            منصة التوريد للمطاعم
            <br />
            والمقاهي
          </div>
        </AbsoluteFill>
      </AbsoluteFill>
      
      <Sequence from={75}>
        <Caption
          text="تعرف على برو تشين"
          startFrame={0}
          position="bottom"
          variant="accent"
          size={80}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
