import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, Sequence } from "remotion";
import { theme } from "../theme";
import { fontFamily } from "../fonts";
import { GradientBG, DotPattern } from "../components/Background";
import { Caption } from "../components/Caption";
import { PhoneWithScreen } from "../components/PhoneWithScreen";
import { useKenBurns } from "../animations";

// Single screen segment with slide transition
const ScreenSegment: React.FC<{
  file: string;
  startFrame: number;
  duration: number;
  label: string;
}> = ({ file, startFrame, duration, label }) => {
  const frame = useCurrentFrame();
  const relFrame = frame - startFrame;
  
  // Slide in from right, slide out to left
  const slideIn = interpolate(relFrame, [0, 15], [100, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const slideOut = interpolate(relFrame, [duration - 15, duration], [0, -100], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const opacity = interpolate(
    relFrame,
    [0, 10, duration - 10, duration],
    [0, 1, 1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );
  const kenBurns = useKenBurns(startFrame, duration, 1.08);
  
  const offset = slideIn + slideOut;
  
  if (frame < startFrame || frame > startFrame + duration) return null;
  
  return (
    <div
      style={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: `translate(-50%, -50%) translateX(${offset}%)`,
        opacity,
      }}
    >
      <div style={{ ...kenBurns, transformOrigin: "center" }}>
        <PhoneWithScreen screenFile={file} scale={0.78} />
      </div>
      
      {/* Step label below phone */}
      <div
        style={{
          position: "absolute",
          bottom: -80,
          left: "50%",
          transform: "translateX(-50%)",
          background: theme.colors.white,
          padding: "14px 32px",
          borderRadius: 999,
          fontFamily: fontFamily.body,
          fontSize: 28,
          fontWeight: 800,
          color: theme.colors.primary,
          boxShadow: theme.shadows.md,
          direction: "rtl",
          whiteSpace: "nowrap",
        }}
      >
        {label}
      </div>
    </div>
  );
};

export const Scene4Demo: React.FC = () => {
  // Scene is 10s = 300 frames, split into 3 segments of 100 frames each
  return (
    <AbsoluteFill>
      <GradientBG variant="cream" />
      <DotPattern opacity={0.08} />
      
      <ScreenSegment file="home.png" startFrame={0} duration={100} label="تصفح الموردين" />
      <ScreenSegment file="products.png" startFrame={100} duration={100} label="اختر المنتجات" />
      <ScreenSegment file="orders.png" startFrame={200} duration={100} label="تتبع طلبك" />
      
      <Sequence from={10}>
        <Caption
          text="سهل. سريع. موثوق."
          startFrame={0}
          position="top"
          variant="accent"
          size={64}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
