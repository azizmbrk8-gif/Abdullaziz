import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, Sequence } from "remotion";
import { theme } from "../theme";
import { fontFamily } from "../fonts";
import { GradientBG } from "../components/Background";
import { Caption } from "../components/Caption";
import { PhoneWithScreen } from "../components/PhoneWithScreen";

const RoleCard: React.FC<{
  label: string;
  subtitle: string;
  screenFile: string;
  startFrame: number;
  slideFrom: "left" | "right";
}> = ({ label, subtitle, screenFile, startFrame, slideFrom }) => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame, [startFrame, startFrame + 20], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const xOffset = slideFrom === "left" ? -300 : 300;
  
  return (
    <div
      style={{
        opacity: progress,
        transform: `translateX(${(1 - progress) * xOffset}px)`,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 20,
      }}
    >
      <div style={{ transform: "scale(0.4)", transformOrigin: "top center", marginBottom: -600 }}>
        <PhoneWithScreen screenFile={screenFile} scale={1} />
      </div>
      <div
        style={{
          textAlign: "center",
          background: theme.colors.white,
          padding: "18px 32px",
          borderRadius: 24,
          boxShadow: theme.shadows.md,
          minWidth: 380,
          direction: "rtl",
        }}
      >
        <div
          style={{
            fontFamily: fontFamily.display,
            fontSize: 42,
            fontWeight: 900,
            color: theme.colors.ink,
          }}
        >
          {label}
        </div>
        <div
          style={{
            fontFamily: fontFamily.body,
            fontSize: 24,
            color: theme.colors.primary,
            fontWeight: 700,
            marginTop: 4,
          }}
        >
          {subtitle}
        </div>
      </div>
    </div>
  );
};

const HandshakeBolt: React.FC<{ startFrame: number }> = ({ startFrame }) => {
  const frame = useCurrentFrame();
  const scale = interpolate(frame, [startFrame, startFrame + 15], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const pulse = 1 + Math.sin((frame - startFrame) * 0.2) * 0.08;
  
  return (
    <div
      style={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: `translate(-50%, -50%) scale(${scale * pulse})`,
        zIndex: 5,
      }}
    >
      <div
        style={{
          width: 160,
          height: 160,
          borderRadius: "50%",
          background: theme.gradients.primary,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 84,
          boxShadow: theme.shadows.glow,
        }}
      >
        🤝
      </div>
    </div>
  );
};

export const Scene7WinWin: React.FC = () => {
  return (
    <AbsoluteFill>
      <GradientBG variant="cream" />
      
      <AbsoluteFill
        style={{
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "row",
          gap: 40,
          padding: "300px 20px 220px",
          position: "relative",
        }}
      >
        <RoleCard
          label="المطاعم"
          subtitle="كفاءة أعلى"
          screenFile="buyer_account.png"
          startFrame={0}
          slideFrom="left"
        />
        <RoleCard
          label="الموردون"
          subtitle="مبيعات أكثر"
          screenFile="supplier_account.png"
          startFrame={15}
          slideFrom="right"
        />
        
        <HandshakeBolt startFrame={35} />
      </AbsoluteFill>
      
      <Sequence from={0}>
        <Caption
          text="ننمو معاً"
          startFrame={0}
          position="top"
          variant="accent"
          size={76}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
