import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, Sequence } from "remotion";
import { theme } from "../theme";
import { fontFamily } from "../fonts";
import { Caption } from "../components/Caption";
import { usePop } from "../animations";

const Notification: React.FC<{
  text: string;
  icon: string;
  x: number;
  y: number;
  startFrame: number;
  rotation?: number;
}> = ({ text, icon, x, y, startFrame, rotation = 0 }) => {
  const anim = usePop(startFrame);
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        ...anim,
        transform: `${anim.transform} rotate(${rotation}deg)`,
        background: theme.colors.white,
        borderRadius: 20,
        padding: "16px 24px",
        display: "flex",
        alignItems: "center",
        gap: 14,
        boxShadow: theme.shadows.md,
        fontFamily: fontFamily.body,
        minWidth: 420,
        direction: "rtl",
      }}
    >
      <div
        style={{
          width: 48,
          height: 48,
          borderRadius: 12,
          background: "#FFE5E5",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 26,
        }}
      >
        {icon}
      </div>
      <div style={{ textAlign: "right", flex: 1 }}>
        <div style={{ fontSize: 22, fontWeight: 800, color: theme.colors.ink }}>
          {text}
        </div>
        <div style={{ fontSize: 16, color: theme.colors.inkMuted, marginTop: 2 }}>
          الآن
        </div>
      </div>
    </div>
  );
};

const StressedOwner: React.FC = () => {
  const frame = useCurrentFrame();
  const shake = Math.sin(frame * 0.5) * 2;
  
  return (
    <div
      style={{
        position: "absolute",
        bottom: 160,
        left: "50%",
        transform: `translateX(-50%) translateX(${shake}px)`,
        width: 480,
        height: 620,
      }}
    >
      <svg viewBox="0 0 480 620" width="100%" height="100%">
        <defs>
          <linearGradient id="ownerGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#3A4552" />
            <stop offset="100%" stopColor={theme.colors.ink} />
          </linearGradient>
        </defs>
        {/* Head */}
        <circle cx="240" cy="120" r="70" fill="url(#ownerGrad)" />
        {/* Body */}
        <path
          d="M 130 210 Q 240 190 350 210 L 370 620 L 110 620 Z"
          fill="url(#ownerGrad)"
        />
        {/* Apron highlights */}
        <rect x="180" y="230" width="120" height="6" fill="#4A5560" />
        {/* Phone */}
        <rect
          x="210"
          y="320"
          width="60"
          height="100"
          rx="8"
          fill={theme.colors.ink}
          stroke={theme.colors.danger}
          strokeWidth="3"
        />
        <rect x="216" y="330" width="48" height="80" rx="3" fill={theme.colors.danger} opacity="0.3" />
        {/* Stress lines */}
        <path d="M 140 70 L 160 85" stroke={theme.colors.danger} strokeWidth="4" strokeLinecap="round" />
        <path d="M 320 70 L 340 85" stroke={theme.colors.danger} strokeWidth="4" strokeLinecap="round" />
        <path d="M 240 30 L 240 45" stroke={theme.colors.danger} strokeWidth="4" strokeLinecap="round" />
      </svg>
    </div>
  );
};

export const Scene1Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const flashOpacity = interpolate(frame, [0, 5, 10], [0, 0.6, 0], {
    extrapolateRight: "clamp",
  });
  
  return (
    <AbsoluteFill style={{ background: "#2A1F2D", overflow: "hidden" }}>
      {/* Warm red kitchen glow */}
      <AbsoluteFill
        style={{
          background: "radial-gradient(ellipse at center, rgba(231, 76, 60, 0.25) 0%, transparent 60%)",
        }}
      />
      
      {/* Tile pattern */}
      <AbsoluteFill
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)
          `,
          backgroundSize: "120px 120px",
          opacity: 0.5,
        }}
      />
      
      <StressedOwner />
      
      <Notification
        text="تأخر التوصيل ساعتين"
        icon="⚠️"
        x={60}
        y={280}
        startFrame={15}
        rotation={-5}
      />
      <Notification
        text="أصناف ناقصة"
        icon="📦"
        x={540}
        y={380}
        startFrame={30}
        rotation={4}
      />
      <Notification
        text="المورد لا يرد"
        icon="📵"
        x={80}
        y={520}
        startFrame={45}
        rotation={-3}
      />
      
      <AbsoluteFill
        style={{
          background: theme.colors.danger,
          opacity: flashOpacity,
          mixBlendMode: "multiply",
        }}
      />
      
      <Sequence from={20}>
        <Caption
          text="تعاني من الموردين؟"
          startFrame={0}
          position="top"
          variant="light"
          size={76}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
