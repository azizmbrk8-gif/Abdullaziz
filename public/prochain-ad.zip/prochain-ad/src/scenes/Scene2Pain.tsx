import React from "react";
import { AbsoluteFill, useCurrentFrame, Sequence } from "remotion";
import { theme } from "../theme";
import { fontFamily } from "../fonts";
import { Caption } from "../components/Caption";
import { useFadeInUp } from "../animations";

const PainPanel: React.FC<{
  title: string;
  icon: React.ReactNode;
  startFrame: number;
  bg: string;
}> = ({ title, icon, startFrame, bg }) => {
  const anim = useFadeInUp(startFrame, 15);
  return (
    <div
      style={{
        flex: 1,
        background: bg,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: 40,
        position: "relative",
        overflow: "hidden",
        ...anim,
      }}
    >
      <div style={{ marginBottom: 30 }}>{icon}</div>
      <div
        style={{
          fontFamily: fontFamily.display,
          fontSize: 64,
          fontWeight: 900,
          color: theme.colors.white,
          textAlign: "center",
          lineHeight: 1.1,
          direction: "rtl",
        }}
      >
        {title}
      </div>
    </div>
  );
};

const LateTruckIcon: React.FC = () => {
  const frame = useCurrentFrame();
  const bounce = Math.sin(frame * 0.4) * 4;
  return (
    <div style={{ transform: `translateY(${bounce}px)` }}>
      <svg width="280" height="200" viewBox="0 0 280 200">
        <rect x="20" y="60" width="140" height="90" rx="8" fill={theme.colors.white} />
        <rect x="160" y="85" width="80" height="65" rx="6" fill={theme.colors.white} opacity="0.9" />
        <rect x="170" y="95" width="60" height="35" rx="4" fill={theme.colors.danger} opacity="0.4" />
        <circle cx="60" cy="160" r="22" fill={theme.colors.ink} />
        <circle cx="60" cy="160" r="10" fill={theme.colors.inkMuted} />
        <circle cx="200" cy="160" r="22" fill={theme.colors.ink} />
        <circle cx="200" cy="160" r="10" fill={theme.colors.inkMuted} />
        <circle cx="100" cy="105" r="30" fill={theme.colors.danger} />
        <text x="100" y="118" fontSize="32" textAnchor="middle" fill={theme.colors.white}>⏰</text>
        <line x1="5" y1="80" x2="15" y2="80" stroke={theme.colors.white} strokeWidth="4" opacity="0.6" />
        <line x1="0" y1="100" x2="15" y2="100" stroke={theme.colors.white} strokeWidth="4" opacity="0.4" />
        <line x1="5" y1="120" x2="15" y2="120" stroke={theme.colors.white} strokeWidth="4" opacity="0.6" />
      </svg>
    </div>
  );
};

const WrongBoxIcon: React.FC = () => (
  <svg width="240" height="200" viewBox="0 0 240 200">
    <path d="M 40 60 L 120 30 L 200 60 L 200 170 L 120 190 L 40 170 Z" fill={theme.colors.white} />
    <path d="M 40 60 L 120 90 L 200 60" fill="none" stroke={theme.colors.inkLight} strokeWidth="3" />
    <path d="M 120 90 L 120 190" stroke={theme.colors.inkLight} strokeWidth="3" />
    <circle cx="170" cy="55" r="35" fill={theme.colors.danger} />
    <path d="M 155 40 L 185 70 M 185 40 L 155 70" stroke={theme.colors.white} strokeWidth="6" strokeLinecap="round" />
  </svg>
);

const FrustratedChefIcon: React.FC = () => (
  <svg width="240" height="220" viewBox="0 0 240 220">
    <ellipse cx="120" cy="50" rx="55" ry="35" fill={theme.colors.white} />
    <rect x="75" y="60" width="90" height="30" rx="4" fill={theme.colors.white} />
    <circle cx="120" cy="120" r="45" fill="#FFD4B5" />
    <path d="M 95 105 L 110 112" stroke={theme.colors.ink} strokeWidth="5" strokeLinecap="round" />
    <path d="M 145 105 L 130 112" stroke={theme.colors.ink} strokeWidth="5" strokeLinecap="round" />
    <circle cx="105" cy="120" r="3" fill={theme.colors.ink} />
    <circle cx="135" cy="120" r="3" fill={theme.colors.ink} />
    <path d="M 105 145 Q 120 138 135 145" fill="none" stroke={theme.colors.ink} strokeWidth="4" strokeLinecap="round" />
    <path d="M 70 75 Q 65 65 70 55" fill="none" stroke={theme.colors.danger} strokeWidth="4" strokeLinecap="round" opacity="0.7" />
    <path d="M 170 75 Q 175 65 170 55" fill="none" stroke={theme.colors.danger} strokeWidth="4" strokeLinecap="round" opacity="0.7" />
  </svg>
);

export const Scene2Pain: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: theme.colors.ink }}>
      <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
        <PainPanel
          title="توصيل متأخر"
          icon={<LateTruckIcon />}
          startFrame={0}
          bg="linear-gradient(135deg, #E74C3C 0%, #C0392B 100%)"
        />
        <PainPanel
          title="أصناف خاطئة"
          icon={<WrongBoxIcon />}
          startFrame={20}
          bg="linear-gradient(135deg, #E67E22 0%, #C65F10 100%)"
        />
        <PainPanel
          title="بدون ثقة"
          icon={<FrustratedChefIcon />}
          startFrame={40}
          bg="linear-gradient(135deg, #8E44AD 0%, #5B2C6F 100%)"
        />
      </div>
      
      <Sequence from={60}>
        <Caption
          text="تأخير. أخطاء. لا ثقة."
          startFrame={0}
          position="center"
          variant="light"
          size={68}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
