import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, Sequence } from "remotion";
import { theme } from "../theme";
import { fontFamily } from "../fonts";
import { GradientBG, DotPattern } from "../components/Background";
import { Caption } from "../components/Caption";

const ServiceNode: React.FC<{
  label: string;
  icon: string;
  startFrame: number;
  bgColor: string;
}> = ({ label, icon, startFrame, bgColor }) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [startFrame, startFrame + 12], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const scale = interpolate(frame, [startFrame, startFrame + 12], [0.7, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const pulse = 1 + Math.sin((frame - startFrame) * 0.1) * 0.02;
  
  return (
    <div
      style={{
        opacity,
        transform: `scale(${scale * pulse})`,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 20,
      }}
    >
      <div
        style={{
          width: 220,
          height: 220,
          borderRadius: "50%",
          background: bgColor,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 100,
          boxShadow: theme.shadows.lg,
          position: "relative",
        }}
      >
        {icon}
        <div
          style={{
            position: "absolute",
            inset: -16,
            borderRadius: "50%",
            border: `3px dashed ${theme.colors.primary}`,
            opacity: 0.3,
            transform: `rotate(${frame * 0.5}deg)`,
          }}
        />
      </div>
      <div
        style={{
          fontFamily: fontFamily.display,
          fontSize: 40,
          fontWeight: 900,
          color: theme.colors.ink,
          direction: "rtl",
        }}
      >
        {label}
      </div>
    </div>
  );
};

const Connector: React.FC<{ startFrame: number }> = ({ startFrame }) => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame, [startFrame, startFrame + 20], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const dotPos = interpolate(
    frame - startFrame,
    [0, 60],
    [0, 100],
    { extrapolateRight: "extend" }
  );
  
  return (
    <div
      style={{
        position: "relative",
        width: 6,
        height: 80,
        margin: "0 auto",
      }}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          background: theme.colors.primary,
          opacity: 0.25,
          borderRadius: 3,
          transform: `scaleY(${progress})`,
          transformOrigin: "top",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: `${(dotPos % 100)}%`,
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: 20,
          height: 20,
          borderRadius: "50%",
          background: theme.colors.gold,
          boxShadow: `0 0 20px ${theme.colors.gold}`,
          opacity: progress,
        }}
      />
    </div>
  );
};

export const Scene6Service: React.FC = () => {
  return (
    <AbsoluteFill>
      <GradientBG variant="cream" />
      <DotPattern opacity={0.08} />
      
      <AbsoluteFill
        style={{
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: 20,
          paddingTop: 300,
          paddingBottom: 220,
        }}
      >
        <ServiceNode
          label="التوريد"
          icon="🌾"
          startFrame={0}
          bgColor="linear-gradient(135deg, #FFF4E0 0%, #FFE0B8 100%)"
        />
        <Connector startFrame={15} />
        <ServiceNode
          label="التخزين"
          icon="📦"
          startFrame={30}
          bgColor="linear-gradient(135deg, #FFE8D6 0%, #FFCBA0 100%)"
        />
        <Connector startFrame={45} />
        <ServiceNode
          label="التوصيل"
          icon="🚚"
          startFrame={60}
          bgColor="linear-gradient(135deg, #FFDAB8 0%, #FFA851 100%)"
        />
      </AbsoluteFill>
      
      <Sequence from={0}>
        <Caption
          text="نهتم بكل شيء"
          startFrame={0}
          position="top"
          variant="accent"
          size={68}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
