import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig, Sequence } from "remotion";
import { theme } from "../theme";
import { fontFamily } from "../fonts";
import { GradientBG } from "../components/Background";
import { Caption } from "../components/Caption";

const BenefitCard: React.FC<{
  title: string;
  desc: string;
  icon: React.ReactNode;
  startFrame: number;
}> = ({ title, desc, icon, startFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  
  const scale = spring({
    frame: frame - startFrame,
    fps,
    config: { damping: 12, stiffness: 100 },
  });
  
  const opacity = interpolate(frame, [startFrame, startFrame + 10], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  
  return (
    <div
      style={{
        opacity,
        transform: `translateX(${(1 - scale) * 60}px)`,
        background: theme.colors.white,
        borderRadius: 32,
        padding: "36px 40px",
        display: "flex",
        alignItems: "center",
        gap: 32,
        boxShadow: theme.shadows.md,
        marginBottom: 28,
        width: "88%",
        direction: "rtl",
      }}
    >
      <div
        style={{
          width: 120,
          height: 120,
          borderRadius: 28,
          background: theme.gradients.primary,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        {icon}
      </div>
      <div style={{ flex: 1 }}>
        <div
          style={{
            fontFamily: fontFamily.display,
            fontSize: 46,
            fontWeight: 900,
            color: theme.colors.ink,
            lineHeight: 1.05,
            marginBottom: 8,
          }}
        >
          {title}
        </div>
        <div
          style={{
            fontFamily: fontFamily.body,
            fontSize: 26,
            color: theme.colors.inkMuted,
            lineHeight: 1.3,
            fontWeight: 500,
          }}
        >
          {desc}
        </div>
      </div>
    </div>
  );
};

const CheckIcon: React.FC<{ startFrame: number }> = ({ startFrame }) => {
  const frame = useCurrentFrame();
  const draw = interpolate(frame, [startFrame + 5, startFrame + 20], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <svg width="68" height="68" viewBox="0 0 64 64">
      <path
        d="M 14 32 L 28 46 L 50 20"
        fill="none"
        stroke={theme.colors.white}
        strokeWidth="8"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray="60"
        strokeDashoffset={60 - draw * 60}
      />
    </svg>
  );
};

const ShieldIcon: React.FC<{ startFrame: number }> = ({ startFrame }) => {
  const frame = useCurrentFrame();
  const pulse = 1 + Math.sin((frame - startFrame) * 0.15) * 0.04;
  return (
    <div style={{ transform: `scale(${pulse})` }}>
      <svg width="68" height="68" viewBox="0 0 64 64">
        <path
          d="M 32 6 L 54 16 L 54 32 Q 54 50 32 58 Q 10 50 10 32 L 10 16 Z"
          fill={theme.colors.white}
        />
        <path
          d="M 22 32 L 30 40 L 44 24"
          fill="none"
          stroke={theme.colors.primary}
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
};

const RocketIcon: React.FC<{ startFrame: number }> = ({ startFrame }) => {
  const frame = useCurrentFrame();
  const lift = Math.sin((frame - startFrame) * 0.2) * 3;
  return (
    <div style={{ transform: `translateY(${lift}px)` }}>
      <svg width="68" height="68" viewBox="0 0 64 64">
        <path
          d="M 32 8 Q 44 20 44 40 L 44 48 L 32 52 L 20 48 L 20 40 Q 20 20 32 8 Z"
          fill={theme.colors.white}
        />
        <circle cx="32" cy="28" r="6" fill={theme.colors.primary} />
        <path
          d="M 24 48 Q 28 56 32 52 Q 36 56 40 48"
          fill={theme.colors.gold}
        />
      </svg>
    </div>
  );
};

export const Scene5Benefits: React.FC = () => {
  return (
    <AbsoluteFill>
      <GradientBG variant="cream" />
      
      <AbsoluteFill
        style={{
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          padding: "320px 40px 200px",
        }}
      >
        <BenefitCard
          title="موردون موثوقون"
          desc="جميع الموردين معتمدون"
          icon={<ShieldIcon startFrame={5} />}
          startFrame={5}
        />
        <BenefitCard
          title="منصة سهلة"
          desc="اطلب بثوانٍ وليس بساعات"
          icon={<CheckIcon startFrame={30} />}
          startFrame={30}
        />
        <BenefitCard
          title="عمليات أسرع"
          desc="وفّر التكاليف وزد المبيعات"
          icon={<RocketIcon startFrame={55} />}
          startFrame={55}
        />
      </AbsoluteFill>
      
      <Sequence from={0}>
        <Caption
          text="مصممة لنجاحك"
          startFrame={0}
          position="top"
          variant="accent"
          size={68}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
