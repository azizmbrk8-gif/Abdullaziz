import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";

export const GradientBG: React.FC<{
  variant?: "cream" | "primary" | "dark";
}> = ({ variant = "cream" }) => {
  const frame = useCurrentFrame();
  const shift = interpolate(frame, [0, 300], [0, 360], {
    extrapolateRight: "extend",
  });
  
  const bg = {
    cream: theme.gradients.cream,
    primary: theme.gradients.primary,
    dark: `linear-gradient(180deg, ${theme.colors.ink} 0%, ${theme.colors.inkMid} 100%)`,
  }[variant];
  
  return (
    <AbsoluteFill style={{ background: bg }}>
      {/* Warm floating orbs */}
      <div
        style={{
          position: "absolute",
          width: 800,
          height: 800,
          top: "10%",
          left: "-20%",
          background: theme.gradients.warmGlow,
          transform: `translate(${Math.sin(shift * 0.01) * 100}px, ${Math.cos(shift * 0.01) * 80}px)`,
          opacity: 0.6,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 600,
          height: 600,
          bottom: "15%",
          right: "-10%",
          background: theme.gradients.warmGlow,
          transform: `translate(${Math.cos(shift * 0.015) * 120}px, ${Math.sin(shift * 0.015) * 60}px)`,
          opacity: 0.5,
        }}
      />
    </AbsoluteFill>
  );
};

// Subtle dotted pattern overlay
export const DotPattern: React.FC<{ opacity?: number }> = ({ opacity = 0.1 }) => {
  const frame = useCurrentFrame();
  const offset = interpolate(frame, [0, 300], [0, 40], {
    extrapolateRight: "extend",
  });
  
  return (
    <AbsoluteFill
      style={{
        backgroundImage: `radial-gradient(circle, ${theme.colors.primary} 1.5px, transparent 1.5px)`,
        backgroundSize: "40px 40px",
        backgroundPosition: `${offset}px ${offset}px`,
        opacity,
      }}
    />
  );
};
