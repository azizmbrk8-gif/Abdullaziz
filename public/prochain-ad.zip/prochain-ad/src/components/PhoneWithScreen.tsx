import React from "react";
import { Img, staticFile } from "remotion";
import { theme } from "../theme";

// Phone frame wrapping a real app screenshot
export const PhoneWithScreen: React.FC<{
  screenFile: string; // filename in public/screens/
  scale?: number;
  style?: React.CSSProperties;
}> = ({ screenFile, scale = 1, style }) => {
  return (
    <div
      style={{
        width: 560 * scale,
        height: 1140 * scale,
        background: theme.colors.ink,
        borderRadius: 72 * scale,
        padding: 16 * scale,
        boxShadow: theme.shadows.lg,
        position: "relative",
        ...style,
      }}
    >
      {/* Notch */}
      <div
        style={{
          position: "absolute",
          top: 28 * scale,
          left: "50%",
          transform: "translateX(-50%)",
          width: 140 * scale,
          height: 34 * scale,
          background: theme.colors.ink,
          borderRadius: 20 * scale,
          zIndex: 10,
        }}
      />
      <div
        style={{
          width: "100%",
          height: "100%",
          borderRadius: 60 * scale,
          background: theme.colors.white,
          overflow: "hidden",
          position: "relative",
        }}
      >
        <Img
          src={staticFile(`screens/${screenFile}`)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "top",
          }}
        />
      </div>
    </div>
  );
};
