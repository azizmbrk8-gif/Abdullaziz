import React from "react";
import { theme } from "../theme";
import { fontFamily } from "../fonts";

// Matches the actual ProChain logo from the app: interlocking stylized chain shapes
// Dark charcoal primary with gold accent
export const ProChainLogo: React.FC<{
  size?: number;
  showText?: boolean;
  variant?: "light" | "dark"; // text color
}> = ({ size = 200, showText = true, variant = "dark" }) => {
  const textColor = variant === "light" ? theme.colors.white : theme.colors.ink;
  
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: size * 0.1,
      }}
    >
      {/* Chain link mark - stylized interlocking shapes */}
      <svg
        width={size}
        height={size * 0.75}
        viewBox="0 0 200 150"
        style={{ overflow: "visible" }}
      >
        {/* Left chain link - charcoal */}
        <path
          d="M 30 75 
             Q 30 40, 60 40 
             L 90 40 
             Q 110 40, 110 60 
             Q 110 75, 95 75
             L 75 75
             Q 60 75, 60 90
             Q 60 110, 80 110
             L 110 110
             Q 130 110, 130 90"
          fill="none"
          stroke={theme.colors.ink}
          strokeWidth="18"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Right chain link - gold */}
        <path
          d="M 170 75 
             Q 170 40, 140 40 
             L 115 40
             Q 95 40, 95 60
             Q 95 75, 110 75
             L 125 75
             Q 140 75, 140 90
             Q 140 110, 120 110
             L 90 110
             Q 70 110, 70 90"
          fill="none"
          stroke={theme.colors.gold}
          strokeWidth="18"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.95"
        />
      </svg>
      
      {showText && (
        <div
          style={{
            fontFamily: fontFamily.display,
            fontSize: size * 0.18,
            fontWeight: 800,
            color: textColor,
            letterSpacing: size * 0.02,
            textTransform: "uppercase",
          }}
        >
          PROCHAIN
        </div>
      )}
    </div>
  );
};
