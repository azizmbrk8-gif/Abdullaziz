import React from "react";
import { AbsoluteFill } from "remotion";
import { usePop } from "../animations";
import { theme } from "../theme";
import { fontFamily } from "../fonts";

export const Caption: React.FC<{
  text: string;
  startFrame: number;
  position?: "top" | "center" | "bottom";
  variant?: "light" | "dark" | "accent" | "gold";
  size?: number;
}> = ({ text, startFrame, position = "bottom", variant = "accent", size = 72 }) => {
  const anim = usePop(startFrame);
  
  const posStyles: Record<string, React.CSSProperties> = {
    top: { alignItems: "flex-start", paddingTop: 200 },
    center: { alignItems: "center" },
    bottom: { alignItems: "flex-end", paddingBottom: 280 },
  };
  
  const styles = {
    light: { bg: "rgba(255,255,255,0.97)", color: theme.colors.ink },
    dark: { bg: theme.colors.ink, color: theme.colors.white },
    accent: { bg: theme.gradients.primary, color: theme.colors.white },
    gold: { bg: theme.gradients.gold, color: theme.colors.white },
  }[variant];
  
  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        ...posStyles[position],
      }}
    >
      <div
        style={{
          ...anim,
          background: styles.bg,
          color: styles.color,
          padding: "28px 56px",
          borderRadius: 28,
          fontFamily: fontFamily.display,
          fontSize: size,
          fontWeight: 900,
          textAlign: "center",
          maxWidth: "88%",
          lineHeight: 1.15,
          boxShadow: theme.shadows.lg,
          margin: "0 40px",
          direction: "rtl",
        }}
      >
        {text}
      </div>
    </AbsoluteFill>
  );
};
