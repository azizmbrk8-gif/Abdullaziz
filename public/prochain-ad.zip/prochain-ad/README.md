# ProChain TikTok Ad — Remotion Project

A 40-second vertical (9:16, 1080×1920) motion graphics video built with [Remotion](https://www.remotion.dev/). Arabic RTL captions, warm orange brand identity, and real app screenshots embedded in the demo.

## 🚀 Quick Start

```bash
# 1. Install dependencies (first time only)
npm install

# 2. Open Remotion Studio to preview
npm start

# 3. Export the final MP4
npm run render
# → out/prochain-ad.mp4
```

Requires Node.js 18+ installed on your machine.

## 📁 Project Structure

```
prochain-ad/
├── package.json
├── remotion.config.ts
├── tsconfig.json
├── public/
│   └── screens/              ← your 10 real app screenshots
│       ├── login.png
│       ├── home.png
│       ├── notifications.png
│       ├── buyer_account.png
│       ├── supplier_home.png
│       ├── add_product.png
│       ├── supplier_notif.png
│       ├── products.png
│       ├── orders.png
│       └── supplier_account.png
└── src/
    ├── index.ts              ← Remotion entry
    ├── Root.tsx              ← registers the composition
    ├── ProChainAd.tsx        ← main timeline (wires all 8 scenes)
    ├── theme.ts              ← brand colors, gradients, shadows
    ├── fonts.ts              ← Tajawal + Cairo Arabic fonts
    ├── animations.ts         ← reusable animation hooks
    ├── components/
    │   ├── Logo.tsx          ← ProChain chain-link SVG
    │   ├── Caption.tsx       ← bold RTL Arabic captions
    │   ├── Background.tsx    ← warm gradient BGs + dot pattern
    │   └── PhoneWithScreen.tsx  ← phone frame + real screenshot
    └── scenes/
        ├── Scene1Hook.tsx        (0–3s)   تعاني من الموردين؟
        ├── Scene2Pain.tsx        (3–8s)   تأخير. أخطاء. لا ثقة.
        ├── Scene3Intro.tsx       (8–12s)  تعرف على برو تشين
        ├── Scene4Demo.tsx        (12–22s) سهل. سريع. موثوق.
        ├── Scene5Benefits.tsx    (22–29s) مصممة لنجاحك
        ├── Scene6Service.tsx     (29–35s) نهتم بكل شيء
        ├── Scene7WinWin.tsx      (35–38s) ننمو معاً
        └── Scene8CTA.tsx         (38–40s) انضم اليوم
```

## 🎨 Customization

### Change brand colors
Edit `src/theme.ts` — primary orange, gold accent, charcoal ink are all defined there.

### Change captions
Each scene has its caption in the scene file (`src/scenes/SceneXxx.tsx`). Search for `<Caption text="..."` and edit.

### Adjust timing
All scene timing lives in `src/ProChainAd.tsx`. Numbers are in frames at 30fps (90 frames = 3 seconds).

### Swap screenshots
Replace the PNGs in `public/screens/` keeping the same filenames, or edit `src/scenes/Scene4Demo.tsx` and `src/scenes/Scene7WinWin.tsx` to reference different files.

## 🔊 Adding Voiceover & Music

Remotion supports audio natively. After recording/generating your voiceover:

1. Drop the audio files into `public/audio/`
2. Import `Audio` and `staticFile` from `"remotion"`
3. Add to `ProChainAd.tsx`:

```tsx
import { Audio, staticFile } from "remotion";

<Audio src={staticFile("audio/voiceover.mp3")} />
<Audio src={staticFile("audio/music.mp3")} volume={0.15} />
```

**Recommended tools:**
- **Voiceover (Arabic):** ElevenLabs has excellent Arabic voices
- **Music:** Artlist, Epidemic Sound, or Uppbeat (free tier) — search "upbeat corporate tech"

## 📦 Rendering Options

```bash
# Default H.264 MP4 (best for TikTok/Instagram)
npm run render

# Custom output path
npx remotion render ProChainAd my-video.mp4

# Render a single frame as PNG (for thumbnail)
npx remotion still ProChainAd thumb.png --frame=300
```

## 🌐 GitHub

To version-control this project:

```bash
cd prochain-ad
git init
git add .
git commit -m "Initial ProChain ad"
gh repo create prochain-ad --public --source=. --push
```

## 📚 Remotion Docs

- [Remotion documentation](https://www.remotion.dev/docs)
- [Animation guide](https://www.remotion.dev/docs/animating-properties)
- [Rendering options](https://www.remotion.dev/docs/render)

---

Built with [Remotion](https://www.remotion.dev/) · Fonts by [Google Fonts](https://fonts.google.com/) (Tajawal, Cairo)
